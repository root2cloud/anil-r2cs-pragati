# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.tools.misc import xlsxwriter
import json
import collections
import datetime
import io


class KsDynamicFinancialXlsxTB(models.Model):
    _inherit = 'ks.dynamic.financial.base'

    def ks_get_xlsx_trial_balance(self, ks_df_informations):
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        row_pos = 0
        lang = self.env.user.lang
        lang_id = self.env['res.lang'].search([('code', '=', lang)])['date_format'].replace('/', '-')

        # Get company and date information
        company_id = ks_df_informations.get('company_id')
        start_date = ks_df_informations['date'].get('ks_start_date')
        end_date = ks_df_informations['date'].get('ks_end_date')

        # Build trial balance data from scratch instead of relying on ks_process_trial_balance
        move_lines = self._build_complete_trial_balance(company_id, start_date, end_date)

        ks_company_id = self.env['res.company'].sudo().browse(company_id)
        sheet = workbook.add_worksheet('Trial_balance')

        # Set column widths
        sheet.set_column(0, 0, 35)  # Particulars
        sheet.set_column(1, 1, 12)  # Code
        sheet.set_column(2, 2, 15)  # Dr (Op bal)
        sheet.set_column(3, 3, 15)  # Cr (Op bal)
        sheet.set_column(4, 4, 15)  # Debits for the period
        sheet.set_column(5, 5, 15)  # Credits for the period
        sheet.set_column(6, 6, 15)  # Dr (YTD)
        sheet.set_column(7, 7, 15)  # Cr (YTD)
        sheet.set_column(8, 8, 25)  # Account Group Name

        # Define formats (keeping your existing format definitions)
        format_title = workbook.add_format({
            'bold': True,
            'align': 'center',
            'font_size': 12,
            'font': 'Arial',
            'bg_color': '#4472C4',
            'font_color': 'white'
        })

        format_company = workbook.add_format({
            'bold': True,
            'align': 'center',
            'font_size': 11,
            'font': 'Arial',
        })

        format_date_range = workbook.add_format({
            'bold': True,
            'align': 'center',
            'font_size': 10,
            'font': 'Arial',
            'italic': True
        })

        format_header = workbook.add_format({
            'bold': True,
            'font_size': 10,
            'font': 'Arial',
            'align': 'center',
            'bg_color': '#4472C4',
            'font_color': 'white',
            'border': 1,
            'text_wrap': True
        })

        format_subheader = workbook.add_format({
            'bold': True,
            'font_size': 9,
            'font': 'Arial',
            'align': 'center',
            'bg_color': '#4472C4',
            'font_color': 'white',
            'border': 1
        })

        line_header_light_left = workbook.add_format({
            'bold': False,
            'font_size': 10,
            'align': 'left',
            'font': 'Arial',
            'border': 1
        })

        line_header_light_center = workbook.add_format({
            'bold': False,
            'font_size': 10,
            'align': 'center',
            'font': 'Arial',
            'border': 1
        })

        line_header_light_right = workbook.add_format({
            'bold': False,
            'font_size': 10,
            'align': 'right',
            'font': 'Arial',
            'border': 1
        })
        line_header_light_right.set_num_format('#,##0.00')

        # Total row format
        line_header_total_left = workbook.add_format({
            'bold': True,
            'font_size': 10,
            'align': 'left',
            'font': 'Arial',
            'border': 1,
            'top': 2,
            'bottom': 2,
        })

        line_header_total_center = workbook.add_format({
            'bold': True,
            'font_size': 10,
            'align': 'center',
            'font': 'Arial',
            'border': 1,
            'top': 2,
            'bottom': 2,
        })

        line_header_total_right = workbook.add_format({
            'bold': True,
            'font_size': 10,
            'align': 'right',
            'font': 'Arial',
            'border': 1,
            'top': 2,
            'bottom': 2,
        })
        line_header_total_right.set_num_format('#,##0.00')

        # Date formatting
        ks_new_start_date = (datetime.datetime.strptime(start_date, '%Y-%m-%d').date()).strftime('%d/%m/%Y')
        ks_new_end_date = (datetime.datetime.strptime(end_date, '%Y-%m-%d').date()).strftime('%d/%m/%Y')

        # Dynamic date range text based on selection
        def get_dynamic_date_range_text():
            date_process = ks_df_informations['date'].get('ks_process', 'range')

            if date_process == 'range':
                return f'[Custom Range ({ks_new_start_date} to {ks_new_end_date})]'
            else:
                date_filter = ks_df_informations.get('date_filter', '')

                if date_filter:
                    filter_mapping = {
                        'last_financial_year': f'[Last Financial Year ({ks_new_start_date} to {ks_new_end_date})]',
                        'this_financial_year': f'[This Financial Year ({ks_new_start_date} to {ks_new_end_date})]',
                        'this_quarter': f'[This Quarter ({ks_new_start_date} to {ks_new_end_date})]',
                        'last_quarter': f'[Last Quarter ({ks_new_start_date} to {ks_new_end_date})]',
                        'this_month': f'[This Month ({ks_new_start_date} to {ks_new_end_date})]',
                        'last_month': f'[Last Month ({ks_new_start_date} to {ks_new_end_date})]',
                        'today': f'[Today ({ks_new_end_date})]',
                        'yesterday': f'[Yesterday ({ks_new_end_date})]',
                        'this_year': f'[This Year ({ks_new_start_date} to {ks_new_end_date})]',
                        'last_year': f'[Last Year ({ks_new_start_date} to {ks_new_end_date})]'
                    }
                    return filter_mapping.get(date_filter, f'[Date Range ({ks_new_start_date} to {ks_new_end_date})]')
                else:
                    return f'[Date Range ({ks_new_start_date} to {ks_new_end_date})]'

        # Company name header
        sheet.merge_range(row_pos, 0, row_pos, 8, ks_company_id.name.upper(), format_company)
        row_pos += 1

        # Trial balance title
        sheet.merge_range(row_pos, 0, row_pos, 8, 'Trial balance', format_title)
        row_pos += 2

        # Dynamic date range
        date_range_text = get_dynamic_date_range_text()
        sheet.merge_range(row_pos, 0, row_pos, 8, date_range_text, format_date_range)
        row_pos += 2

        # Main column headers
        sheet.write_string(row_pos, 0, 'Particulars', format_header)
        sheet.write_string(row_pos, 1, 'Code', format_header)
        sheet.merge_range(row_pos, 2, row_pos, 3, 'Opening Balance', format_header)
        sheet.merge_range(row_pos, 4, row_pos, 5, 'Transaction', format_header)
        sheet.merge_range(row_pos, 6, row_pos, 7, 'Closing Balance', format_header)
        sheet.write_string(row_pos, 8, 'Account Group Name', format_header)
        row_pos += 1

        # Sub headers
        sheet.write_string(row_pos, 0, '', format_subheader)
        sheet.write_string(row_pos, 1, '', format_subheader)
        sheet.write_string(row_pos, 2, 'Dr (Op bal)', format_subheader)
        sheet.write_string(row_pos, 3, 'Cr (Op bal)', format_subheader)
        sheet.write_string(row_pos, 4, 'Debits for the period', format_subheader)
        sheet.write_string(row_pos, 5, 'Credits for the period', format_subheader)
        sheet.write_string(row_pos, 6, 'Dr (YTD)', format_subheader)
        sheet.write_string(row_pos, 7, 'Cr (YTD)', format_subheader)
        sheet.write_string(row_pos, 8, '', format_subheader)
        row_pos += 1

        # Function to get account group name
        def get_account_group_name(account_code):
            if not account_code:
                return 'Other'

            try:
                code_num = int(account_code)

                if 100101 <= code_num <= 100150:
                    return 'Current Assets'
                elif 100151 <= code_num <= 100175:
                    return 'GST Input'
                elif 100176 <= code_num <= 100200:
                    return 'Sundry Debtors'
                elif 100201 <= code_num <= 100250:
                    return 'Inventory'
                elif 100251 <= code_num <= 100300:
                    return 'Prepaid Expenses'
                elif 100301 <= code_num <= 100399:
                    return 'Fixed Assets'
                elif 200000 <= code_num <= 200099:
                    return 'Current Liabilities'
                elif 200700 <= code_num <= 200799:
                    return 'Other Current Liabilities'
                elif 300000 <= code_num <= 399999:
                    return 'Expenses'
                elif 400000 <= code_num <= 499999:
                    return 'Income'
                elif 500000 <= code_num <= 599999:
                    return 'Bank and Cash'
                elif 600000 <= code_num <= 699999:
                    return 'Sundry Creditors'
                elif 700000 <= code_num <= 799999:
                    return 'Other Liabilities'
                elif 1000000 <= code_num <= 1999999:
                    return 'Other Expenses'
                else:
                    first_digit = str(code_num)[0]
                    if first_digit == '1':
                        return 'Assets'
                    elif first_digit == '2':
                        return 'Liabilities'
                    elif first_digit == '3':
                        return 'Expenses'
                    elif first_digit == '4':
                        return 'Income'
                    elif first_digit == '5':
                        return 'Bank and Cash'
                    elif first_digit == '6':
                        return 'Sundry Creditors'
                    elif first_digit == '7':
                        return 'Other Liabilities'
                    else:
                        return 'Other'

            except (ValueError, TypeError):
                code_upper = str(account_code).upper()
                if code_upper.startswith(('GST', 'IGST', 'CGST', 'SGST')):
                    return 'GST Input'
                elif code_upper.startswith(('ADV', 'ADVANCE')):
                    return 'Advances'
                elif code_upper.startswith(('SAL', 'SALARY')):
                    return 'Employee Advances'
                elif code_upper.startswith(('BANK', 'CASH')):
                    return 'Bank and Cash'
                elif code_upper.startswith(('SHARE', 'EQUITY')):
                    return 'Equity'
                elif code_upper.startswith(('TDS', 'TCS')):
                    return 'Tax Related'
                else:
                    return 'Other'

        # Initialize totals
        total_initial_debit = 0.0
        total_initial_credit = 0.0
        total_debit = 0.0
        total_credit = 0.0
        total_ending_debit = 0.0
        total_ending_credit = 0.0

        # Sort move_lines by account code
        sorted_move_lines = sorted(move_lines.items(), key=lambda x: x[1].get('code', ''))

        # Process individual account lines
        for line_id, line in sorted_move_lines:
            account_name = line.get('name', '')
            account_code = line.get('code', '')

            # Skip if no account code
            if not account_code:
                continue

            group_name = get_account_group_name(account_code)

            initial_debit = float(line.get('initial_debit', 0))
            initial_credit = float(line.get('initial_credit', 0))
            debit = float(line.get('debit', 0))
            credit = float(line.get('credit', 0))
            ending_debit = float(line.get('ending_debit', 0))
            ending_credit = float(line.get('ending_credit', 0))

            # Add to totals
            total_initial_debit += initial_debit
            total_initial_credit += initial_credit
            total_debit += debit
            total_credit += credit
            total_ending_debit += ending_debit
            total_ending_credit += ending_credit

            # Write account details
            sheet.write_string(row_pos, 0, account_name, line_header_light_left)
            sheet.write_string(row_pos, 1, account_code, line_header_light_center)
            sheet.write_number(row_pos, 2, initial_debit, line_header_light_right)
            sheet.write_number(row_pos, 3, initial_credit, line_header_light_right)
            sheet.write_number(row_pos, 4, debit, line_header_light_right)
            sheet.write_number(row_pos, 5, credit, line_header_light_right)
            sheet.write_number(row_pos, 6, ending_debit, line_header_light_right)
            sheet.write_number(row_pos, 7, ending_credit, line_header_light_right)
            sheet.write_string(row_pos, 8, group_name, line_header_light_left)
            row_pos += 1

        # Add Total row
        sheet.write_string(row_pos, 0, 'TOTAL', line_header_total_left)
        sheet.write_string(row_pos, 1, '', line_header_total_center)
        sheet.write_number(row_pos, 2, total_initial_debit, line_header_total_right)
        sheet.write_number(row_pos, 3, total_initial_credit, line_header_total_right)
        sheet.write_number(row_pos, 4, total_debit, line_header_total_right)
        sheet.write_number(row_pos, 5, total_credit, line_header_total_right)
        sheet.write_number(row_pos, 6, total_ending_debit, line_header_total_right)
        sheet.write_number(row_pos, 7, total_ending_credit, line_header_total_right)
        sheet.write_string(row_pos, 8, '', line_header_total_center)

        workbook.close()
        output.seek(0)
        generated_file = output.read()
        output.close()

        return generated_file

    def _build_complete_trial_balance(self, company_id, start_date, end_date):
        """
        Build complete trial balance data by directly querying account.move.line
        This ensures ALL accounts are included, even those missing from ks_process_trial_balance
        """
        move_lines = {}

        # Get all accounts for the company
        all_accounts = self.env['account.account'].search([
            ('company_id', '=', company_id),
            ('deprecated', '=', False)
        ])

        # Initialize all accounts with zero balances
        for account in all_accounts:
            move_lines[account.id] = {
                'name': account.name,
                'code': account.code,
                'initial_debit': 0.0,
                'initial_credit': 0.0,
                'debit': 0.0,
                'credit': 0.0,
                'ending_debit': 0.0,
                'ending_credit': 0.0,
            }

        # Get opening balances (before start_date)
        opening_query = """
            SELECT account_id, 
                   SUM(CASE WHEN debit > credit THEN debit - credit ELSE 0 END) as initial_debit,
                   SUM(CASE WHEN credit > debit THEN credit - debit ELSE 0 END) as initial_credit
            FROM account_move_line aml
            JOIN account_move am ON aml.move_id = am.id
            WHERE aml.company_id = %s
              AND am.state = 'posted'
              AND aml.date < %s
            GROUP BY account_id
        """

        self.env.cr.execute(opening_query, (company_id, start_date))
        opening_results = self.env.cr.fetchall()

        for account_id, initial_debit, initial_credit in opening_results:
            if account_id in move_lines:
                move_lines[account_id]['initial_debit'] = initial_debit or 0.0
                move_lines[account_id]['initial_credit'] = initial_credit or 0.0

        # Get period transactions (between start_date and end_date)
        period_query = """
            SELECT account_id, 
                   SUM(debit) as debit,
                   SUM(credit) as credit
            FROM account_move_line aml
            JOIN account_move am ON aml.move_id = am.id
            WHERE aml.company_id = %s
              AND am.state = 'posted'
              AND aml.date >= %s
              AND aml.date <= %s
            GROUP BY account_id
        """

        self.env.cr.execute(period_query, (company_id, start_date, end_date))
        period_results = self.env.cr.fetchall()

        for account_id, debit, credit in period_results:
            if account_id in move_lines:
                move_lines[account_id]['debit'] = debit or 0.0
                move_lines[account_id]['credit'] = credit or 0.0

        # Calculate ending balances
        for account_id, data in move_lines.items():
            opening_balance = data['initial_debit'] - data['initial_credit']
            period_balance = data['debit'] - data['credit']
            ending_balance = opening_balance + period_balance

            if ending_balance > 0:
                data['ending_debit'] = ending_balance
                data['ending_credit'] = 0.0
            else:
                data['ending_debit'] = 0.0
                data['ending_credit'] = abs(ending_balance)

        return move_lines
