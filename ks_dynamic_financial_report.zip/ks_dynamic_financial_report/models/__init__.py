# -*- coding: utf-8 -*-

from . import ks_dynamic_financial_report_base
from . import ks_res_company
from . import ir_action
from . import ks_dynamic_financial_reports
from . import ks_res_config_settings
from . import ks_account_move_line
from . import ks_dfr_account_type