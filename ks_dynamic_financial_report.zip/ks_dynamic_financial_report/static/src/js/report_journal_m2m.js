odoo.ksJournalFilterSearch = function(input) {
    var filter = input.value.toUpperCase();
    var list = input.parentNode.querySelectorAll(".ks-journal-item");
    for (var i = 0; i < list.length; i++) {
        var item = list[i];
        if (item.textContent.toUpperCase().indexOf(filter) > -1) {
            item.style.display = "";
        } else {
            item.style.display = "none";
        }
    }
};

//// Control when dropdown appears
//document.addEventListener('DOMContentLoaded', function () {
//    var searchInputs = document.querySelectorAll('.ks-search-input'); // add this class to your search inputs
//
//    searchInputs.forEach(function (input) {
//        var dropdown = input.parentNode.querySelector('.ks-journal-list'); // container for journal items
//
//        // Hide dropdown initially
//        if (dropdown) dropdown.style.display = 'none';
//
//        // Show dropdown when input is focused (clicked)
//        input.addEventListener('focus', function () {
//            if (dropdown) dropdown.style.display = 'block';
//        });
//
//        // Hide dropdown when input loses focus (clicks outside)
//        input.addEventListener('blur', function () {
//            setTimeout(function () {
//                if (dropdown) dropdown.style.display = 'none';
//            }, 150); // slight delay to allow item click
//        });
//    });
//});